import React, { useState, useEffect } from 'react';
import { Activity } from 'lucide-react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import TradingView from './components/TradingView';
import MarketData from './components/MarketData';
import OrderBook from './components/OrderBook';
import TradeHistory from './components/TradeHistory';
import Portfolio from './components/Portfolio';
import { CryptoData, MarketData as MarketDataType } from './types/crypto';
import { fetchMarketData, fetchCryptoData } from './services/api';

function App() {
  const [selectedPair, setSelectedPair] = useState('BTC/USDT');
  const [marketData, setMarketData] = useState<MarketDataType | null>(null);
  const [cryptoData, setCryptoData] = useState<CryptoData[]>([]);
  const [loading, setLoading] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  useEffect(() => {
    const loadInitialData = async () => {
      try {
        const [market, crypto] = await Promise.all([
          fetchMarketData(),
          fetchCryptoData()
        ]);
        setMarketData(market);
        setCryptoData(crypto);
      } catch (error) {
        console.error('Failed to load market data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();
    const interval = setInterval(loadInitialData, 10000);
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-dark-primary flex items-center justify-center">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-12 h-12 border-4 border-accent-blue border-t-transparent rounded-full animate-spin"></div>
          <p className="text-text-secondary text-lg">Loading ScanX...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-primary text-white flex flex-col">
      <Header />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar 
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          cryptoData={cryptoData}
          selectedPair={selectedPair}
          onSelectPair={setSelectedPair}
        />
        
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* Market Data Bar */}
          <MarketData marketData={marketData} cryptoData={cryptoData} />
          
          {/* Trading Interface */}
          <div className="flex-1 grid grid-cols-12 gap-1 p-1 overflow-hidden">
            {/* Chart Area */}
            <div className="col-span-8 bg-dark-secondary border border-border-primary rounded-lg overflow-hidden">
              <TradingView selectedPair={selectedPair} />
            </div>
            
            {/* Order Book */}
            <div className="col-span-2 bg-dark-secondary border border-border-primary rounded-lg overflow-hidden">
              <OrderBook selectedPair={selectedPair} />
            </div>
            
            {/* Trade Panel */}
            <div className="col-span-2 flex flex-col space-y-1">
              <div className="flex-1 bg-dark-secondary border border-border-primary rounded-lg overflow-hidden">
                <Portfolio />
              </div>
              <div className="flex-1 bg-dark-secondary border border-border-primary rounded-lg overflow-hidden">
                <TradeHistory />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;