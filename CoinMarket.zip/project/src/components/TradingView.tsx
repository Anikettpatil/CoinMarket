import React, { useState, useEffect } from 'react';
import { BarChart3, Maximize2, Settings, TrendingUp, TrendingDown } from 'lucide-react';

interface TradingViewProps {
  selectedPair: string;
}

const TradingView: React.FC<TradingViewProps> = ({ selectedPair }) => {
  const [timeframe, setTimeframe] = useState('1H');
  const [chartData, setChartData] = useState<number[]>([]);
  const [currentPrice, setCurrentPrice] = useState(0);
  const [priceChange, setPriceChange] = useState(0);
  const [priceChangePercentage, setPriceChangePercentage] = useState(0);

  useEffect(() => {
    const generateMockData = () => {
      const basePrice = Math.random() * 50000 + 20000;
      const data = [];
      let price = basePrice;
      
      for (let i = 0; i < 200; i++) {
        const volatility = (Math.random() - 0.5) * 0.02;
        price = price * (1 + volatility);
        data.push(price);
      }
      
      setChartData(data);
      setCurrentPrice(price);
      
      const previousPrice = data[data.length - 20] || price;
      const change = price - previousPrice;
      const changePercentage = (change / previousPrice) * 100;
      
      setPriceChange(change);
      setPriceChangePercentage(changePercentage);
    };

    generateMockData();
    const interval = setInterval(generateMockData, 3000);
    return () => clearInterval(interval);
  }, [selectedPair, timeframe]);

  const timeframes = ['1m', '5m', '15m', '1H', '4H', '1D', '1W'];

  return (
    <div className="h-full flex flex-col">
      {/* Chart Header */}
      <div className="p-4 border-b border-border-primary">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h3 className="text-xl font-bold text-white">{selectedPair}</h3>
            <div className="flex items-center space-x-2">
              <span className="text-2xl font-bold text-white">
                ${currentPrice.toFixed(2)}
              </span>
              <div className={`flex items-center space-x-1 ${
                priceChange >= 0 ? 'text-accent-green' : 'text-accent-red'
              }`}>
                {priceChange >= 0 ? (
                  <TrendingUp className="w-4 h-4" />
                ) : (
                  <TrendingDown className="w-4 h-4" />
                )}
                <span className="text-sm font-medium">
                  {priceChange >= 0 ? '+' : ''}${priceChange.toFixed(2)} ({priceChange >= 0 ? '+' : ''}{priceChangePercentage.toFixed(2)}%)
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <button className="p-2 text-text-secondary hover:text-white hover:bg-dark-tertiary rounded-lg transition-all duration-200">
              <Settings className="w-4 h-4" />
            </button>
            <button className="p-2 text-text-secondary hover:text-white hover:bg-dark-tertiary rounded-lg transition-all duration-200">
              <Maximize2 className="w-4 h-4" />
            </button>
          </div>
        </div>
        
        {/* Timeframe Selector */}
        <div className="flex space-x-1 mt-4">
          {timeframes.map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-3 py-1 rounded text-sm font-medium transition-all duration-200 ${
                timeframe === tf
                  ? 'bg-accent-blue text-white'
                  : 'text-text-secondary hover:text-white hover:bg-dark-tertiary'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* Chart Area */}
      <div className="flex-1 p-4">
        <div className="relative h-full bg-dark-primary rounded-lg p-4">
          <svg className="w-full h-full" viewBox="0 0 800 400">
            <defs>
              <linearGradient id="chartGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#00d4ff" stopOpacity="0.2" />
                <stop offset="100%" stopColor="#00d4ff" stopOpacity="0" />
              </linearGradient>
            </defs>
            
            {/* Grid Lines */}
            {[...Array(5)].map((_, i) => (
              <line
                key={`h-${i}`}
                x1="0"
                y1={i * 80}
                x2="800"
                y2={i * 80}
                stroke="#1f2937"
                strokeWidth="1"
                opacity="0.3"
              />
            ))}
            {[...Array(9)].map((_, i) => (
              <line
                key={`v-${i}`}
                x1={i * 100}
                y1="0"
                x2={i * 100}
                y2="400"
                stroke="#1f2937"
                strokeWidth="1"
                opacity="0.3"
              />
            ))}
            
            {/* Chart Line */}
            <polyline
              fill="none"
              stroke="#00d4ff"
              strokeWidth="2"
              points={chartData.map((price, index) => {
                const x = (index / (chartData.length - 1)) * 800;
                const minPrice = Math.min(...chartData);
                const maxPrice = Math.max(...chartData);
                const y = 400 - ((price - minPrice) / (maxPrice - minPrice)) * 380;
                return `${x},${y}`;
              }).join(' ')}
            />
            
            {/* Chart Fill */}
            <polygon
              fill="url(#chartGradient)"
              points={chartData.map((price, index) => {
                const x = (index / (chartData.length - 1)) * 800;
                const minPrice = Math.min(...chartData);
                const maxPrice = Math.max(...chartData);
                const y = 400 - ((price - minPrice) / (maxPrice - minPrice)) * 380;
                return `${x},${y}`;
              }).join(' ') + ' 800,400 0,400'}
            />
          </svg>
        </div>
      </div>
    </div>
  );
};

export default TradingView;