import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Star, TrendingUp, TrendingDown, Search } from 'lucide-react';
import { CryptoData } from '../types/crypto';
import { formatPrice, formatPercentage } from '../utils/formatters';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
  cryptoData: CryptoData[];
  selectedPair: string;
  onSelectPair: (pair: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  collapsed, 
  onToggle, 
  cryptoData, 
  selectedPair, 
  onSelectPair 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'favorites' | 'spot' | 'futures'>('spot');
  const [favorites, setFavorites] = useState<Set<string>>(new Set(['bitcoin', 'ethereum']));

  const filteredCoins = cryptoData
    .filter(coin => 
      coin.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      coin.symbol.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .slice(0, 20);

  const toggleFavorite = (coinId: string) => {
    const newFavorites = new Set(favorites);
    if (newFavorites.has(coinId)) {
      newFavorites.delete(coinId);
    } else {
      newFavorites.add(coinId);
    }
    setFavorites(newFavorites);
  };

  const formatPairName = (coin: CryptoData) => `${coin.symbol.toUpperCase()}/USDT`;

  if (collapsed) {
    return (
      <div className="w-12 bg-dark-secondary border-r border-border-primary flex flex-col">
        <button
          onClick={onToggle}
          className="p-3 text-text-secondary hover:text-white hover:bg-dark-tertiary transition-all duration-200"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    );
  }

  return (
    <div className="w-80 bg-dark-secondary border-r border-border-primary flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border-primary">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Markets</h2>
          <button
            onClick={onToggle}
            className="p-1 text-text-secondary hover:text-white hover:bg-dark-tertiary rounded transition-all duration-200"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-text-secondary" />
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-dark-tertiary border border-border-primary rounded-lg pl-10 pr-4 py-2 text-white placeholder-text-secondary focus:outline-none focus:ring-1 focus:ring-accent-blue focus:border-accent-blue transition-all duration-200"
          />
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border-primary">
        {[
          { id: 'favorites', label: 'Favorites' },
          { id: 'spot', label: 'Spot' },
          { id: 'futures', label: 'Futures' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex-1 py-3 px-4 text-sm font-medium transition-all duration-200 ${
              activeTab === tab.id
                ? 'text-accent-blue border-b-2 border-accent-blue bg-dark-tertiary'
                : 'text-text-secondary hover:text-white hover:bg-dark-tertiary'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Market List */}
      <div className="flex-1 overflow-y-auto">
        {/* Header */}
        <div className="grid grid-cols-12 gap-2 p-3 text-xs text-text-secondary font-medium border-b border-border-primary">
          <div className="col-span-1"></div>
          <div className="col-span-5">Pair</div>
          <div className="col-span-3 text-right">Price</div>
          <div className="col-span-3 text-right">24h%</div>
        </div>

        {/* Market Items */}
        <div className="space-y-0">
          {(activeTab === 'favorites' 
            ? filteredCoins.filter(coin => favorites.has(coin.id))
            : filteredCoins
          ).map((coin) => {
            const pairName = formatPairName(coin);
            const isSelected = selectedPair === pairName;
            
            return (
              <div
                key={coin.id}
                onClick={() => onSelectPair(pairName)}
                className={`grid grid-cols-12 gap-2 p-3 cursor-pointer transition-all duration-200 hover:bg-dark-tertiary ${
                  isSelected ? 'bg-dark-tertiary border-r-2 border-accent-blue' : ''
                }`}
              >
                <div className="col-span-1 flex items-center">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(coin.id);
                    }}
                    className={`p-1 rounded transition-colors duration-200 ${
                      favorites.has(coin.id) ? 'text-accent-yellow' : 'text-text-secondary hover:text-accent-yellow'
                    }`}
                  >
                    <Star className={`w-3 h-3 ${favorites.has(coin.id) ? 'fill-current' : ''}`} />
                  </button>
                </div>
                
                <div className="col-span-5 flex items-center space-x-2">
                  <img src={coin.image} alt={coin.name} className="w-5 h-5 rounded-full" />
                  <div>
                    <p className="text-white text-sm font-medium">{coin.symbol.toUpperCase()}</p>
                    <p className="text-text-secondary text-xs">USDT</p>
                  </div>
                </div>
                
                <div className="col-span-3 text-right">
                  <p className="text-white text-sm font-medium">{formatPrice(coin.current_price)}</p>
                </div>
                
                <div className="col-span-3 text-right">
                  <div className={`flex items-center justify-end space-x-1 ${
                    coin.price_change_percentage_24h >= 0 ? 'text-accent-green' : 'text-accent-red'
                  }`}>
                    {coin.price_change_percentage_24h >= 0 ? (
                      <TrendingUp className="w-3 h-3" />
                    ) : (
                      <TrendingDown className="w-3 h-3" />
                    )}
                    <span className="text-sm font-medium">
                      {formatPercentage(Math.abs(coin.price_change_percentage_24h))}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;