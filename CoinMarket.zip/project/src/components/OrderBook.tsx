import React, { useState, useEffect } from 'react';
import { BookOpen } from 'lucide-react';

interface OrderBookProps {
  selectedPair: string;
}

interface OrderBookEntry {
  price: number;
  amount: number;
  total: number;
}

const OrderBook: React.FC<OrderBookProps> = ({ selectedPair }) => {
  const [bids, setBids] = useState<OrderBookEntry[]>([]);
  const [asks, setAsks] = useState<OrderBookEntry[]>([]);

  useEffect(() => {
    const generateOrderBook = () => {
      const basePrice = Math.random() * 50000 + 20000;
      const newBids: OrderBookEntry[] = [];
      const newAsks: OrderBookEntry[] = [];

      for (let i = 0; i < 15; i++) {
        const bidPrice = basePrice - (i + 1) * (Math.random() * 50 + 10);
        const askPrice = basePrice + (i + 1) * (Math.random() * 50 + 10);
        const bidAmount = Math.random() * 5 + 0.1;
        const askAmount = Math.random() * 5 + 0.1;

        newBids.push({
          price: bidPrice,
          amount: bidAmount,
          total: bidPrice * bidAmount,
        });

        newAsks.push({
          price: askPrice,
          amount: askAmount,
          total: askPrice * askAmount,
        });
      }

      setBids(newBids);
      setAsks(newAsks);
    };

    generateOrderBook();
    const interval = setInterval(generateOrderBook, 2000);
    return () => clearInterval(interval);
  }, [selectedPair]);

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border-primary">
        <div className="flex items-center space-x-2">
          <BookOpen className="w-4 h-4 text-accent-blue" />
          <h3 className="text-sm font-semibold text-white">Order Book</h3>
        </div>
      </div>

      {/* Order Book Content */}
      <div className="flex-1 overflow-hidden">
        {/* Column Headers */}
        <div className="grid grid-cols-3 gap-2 p-3 text-xs text-text-secondary font-medium border-b border-border-primary">
          <div>Price</div>
          <div className="text-right">Amount</div>
          <div className="text-right">Total</div>
        </div>

        {/* Asks (Sell Orders) */}
        <div className="h-1/2 overflow-y-auto">
          <div className="space-y-0">
            {asks.slice().reverse().map((ask, index) => (
              <div key={index} className="grid grid-cols-3 gap-2 p-2 text-xs hover:bg-dark-tertiary transition-colors duration-200">
                <div className="text-accent-red font-medium">{ask.price.toFixed(2)}</div>
                <div className="text-text-secondary text-right">{ask.amount.toFixed(4)}</div>
                <div className="text-text-secondary text-right">{ask.total.toFixed(0)}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Spread */}
        <div className="border-y border-border-primary py-2 px-3">
          <div className="flex justify-between items-center">
            <span className="text-xs text-text-secondary">Spread</span>
            <span className="text-xs text-white font-medium">
              {((asks[0]?.price || 0) - (bids[0]?.price || 0)).toFixed(2)}
            </span>
          </div>
        </div>

        {/* Bids (Buy Orders) */}
        <div className="h-1/2 overflow-y-auto">
          <div className="space-y-0">
            {bids.map((bid, index) => (
              <div key={index} className="grid grid-cols-3 gap-2 p-2 text-xs hover:bg-dark-tertiary transition-colors duration-200">
                <div className="text-accent-green font-medium">{bid.price.toFixed(2)}</div>
                <div className="text-text-secondary text-right">{bid.amount.toFixed(4)}</div>
                <div className="text-text-secondary text-right">{bid.total.toFixed(0)}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderBook;