import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { MarketData as MarketDataType, CryptoData } from '../types/crypto';
import { formatMarketCap, formatPercentage } from '../utils/formatters';

interface MarketDataProps {
  marketData: MarketDataType | null;
  cryptoData: CryptoData[];
}

const MarketData: React.FC<MarketDataProps> = ({ marketData, cryptoData }) => {
  const topCoins = cryptoData.slice(0, 6);

  return (
    <div className="bg-dark-secondary border-b border-border-primary p-3">
      <div className="flex items-center space-x-8 overflow-x-auto">
        {/* Global Market Stats */}
        {marketData && (
          <>
            <div className="flex items-center space-x-2 whitespace-nowrap">
              <span className="text-text-secondary text-sm">Market Cap:</span>
              <span className="text-white font-medium">{formatMarketCap(marketData.total_market_cap.usd)}</span>
              <span className={`text-sm ${marketData.market_cap_change_percentage_24h_usd >= 0 ? 'text-accent-green' : 'text-accent-red'}`}>
                {marketData.market_cap_change_percentage_24h_usd >= 0 ? '+' : ''}{formatPercentage(marketData.market_cap_change_percentage_24h_usd)}
              </span>
            </div>
            
            <div className="flex items-center space-x-2 whitespace-nowrap">
              <span className="text-text-secondary text-sm">24h Vol:</span>
              <span className="text-white font-medium">{formatMarketCap(marketData.total_volume.usd)}</span>
            </div>
            
            <div className="flex items-center space-x-2 whitespace-nowrap">
              <span className="text-text-secondary text-sm">BTC Dom:</span>
              <span className="text-white font-medium">{marketData.market_cap_percentage.btc.toFixed(1)}%</span>
            </div>
          </>
        )}

        {/* Top Coins Ticker */}
        <div className="flex items-center space-x-6">
          {topCoins.map((coin) => (
            <div key={coin.id} className="flex items-center space-x-2 whitespace-nowrap">
              <img src={coin.image} alt={coin.name} className="w-4 h-4 rounded-full" />
              <span className="text-white text-sm font-medium">{coin.symbol.toUpperCase()}</span>
              <span className="text-white text-sm">${coin.current_price.toFixed(2)}</span>
              <span className={`text-sm ${coin.price_change_percentage_24h >= 0 ? 'text-accent-green' : 'text-accent-red'}`}>
                {coin.price_change_percentage_24h >= 0 ? '+' : ''}{coin.price_change_percentage_24h.toFixed(2)}%
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MarketData;