import React, { useState } from 'react';
import { Wallet, TrendingUp, TrendingDown } from 'lucide-react';

const Portfolio: React.FC = () => {
  const [orderType, setOrderType] = useState<'buy' | 'sell'>('buy');
  const [amount, setAmount] = useState('');
  const [price, setPrice] = useState('');

  const portfolioData = [
    { asset: 'BTC', amount: 0.5432, value: 27160, change: 2.34 },
    { asset: 'ETH', amount: 2.1, value: 7350, change: -1.23 },
    { asset: 'BNB', amount: 15.7, value: 5495, change: 0.87 },
  ];

  const totalValue = portfolioData.reduce((sum, item) => sum + item.value, 0);

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border-primary">
        <div className="flex items-center space-x-2">
          <Wallet className="w-4 h-4 text-accent-blue" />
          <h3 className="text-sm font-semibold text-white">Portfolio</h3>
        </div>
      </div>

      {/* Portfolio Summary */}
      <div className="p-4 border-b border-border-primary">
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-text-secondary text-sm">Total Value</span>
            <span className="text-white font-medium">${totalValue.toLocaleString()}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-text-secondary text-sm">24h P&L</span>
            <span className="text-accent-green font-medium">+$234.56 (+1.2%)</span>
          </div>
        </div>
      </div>

      {/* Holdings */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4">
          <h4 className="text-xs text-text-secondary font-medium mb-3">HOLDINGS</h4>
          <div className="space-y-2">
            {portfolioData.map((item) => (
              <div key={item.asset} className="flex items-center justify-between p-2 hover:bg-dark-tertiary rounded transition-colors duration-200">
                <div>
                  <p className="text-white text-sm font-medium">{item.asset}</p>
                  <p className="text-text-secondary text-xs">{item.amount}</p>
                </div>
                <div className="text-right">
                  <p className="text-white text-sm">${item.value.toLocaleString()}</p>
                  <p className={`text-xs ${item.change >= 0 ? 'text-accent-green' : 'text-accent-red'}`}>
                    {item.change >= 0 ? '+' : ''}{item.change}%
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Trade */}
      <div className="p-4 border-t border-border-primary">
        <h4 className="text-xs text-text-secondary font-medium mb-3">QUICK TRADE</h4>
        
        <div className="flex space-x-1 mb-3">
          <button
            onClick={() => setOrderType('buy')}
            className={`flex-1 py-2 px-3 rounded text-sm font-medium transition-all duration-200 ${
              orderType === 'buy'
                ? 'bg-accent-green text-black'
                : 'bg-dark-tertiary text-text-secondary hover:bg-border-primary'
            }`}
          >
            Buy
          </button>
          <button
            onClick={() => setOrderType('sell')}
            className={`flex-1 py-2 px-3 rounded text-sm font-medium transition-all duration-200 ${
              orderType === 'sell'
                ? 'bg-accent-red text-white'
                : 'bg-dark-tertiary text-text-secondary hover:bg-border-primary'
            }`}
          >
            Sell
          </button>
        </div>

        <div className="space-y-2">
          <input
            type="number"
            placeholder="Amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full bg-dark-tertiary border border-border-primary rounded px-3 py-2 text-white text-sm placeholder-text-secondary focus:outline-none focus:ring-1 focus:ring-accent-blue focus:border-accent-blue"
          />
          <input
            type="number"
            placeholder="Price"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            className="w-full bg-dark-tertiary border border-border-primary rounded px-3 py-2 text-white text-sm placeholder-text-secondary focus:outline-none focus:ring-1 focus:ring-accent-blue focus:border-accent-blue"
          />
          <button
            className={`w-full py-2 px-3 rounded text-sm font-medium transition-all duration-200 ${
              orderType === 'buy'
                ? 'bg-accent-green hover:bg-green-500 text-black'
                : 'bg-accent-red hover:bg-red-600 text-white'
            }`}
          >
            {orderType === 'buy' ? 'Buy' : 'Sell'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Portfolio;