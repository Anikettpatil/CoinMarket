import React, { useState } from 'react';
import { Search, Filter, Star, TrendingUp, TrendingDown } from 'lucide-react';
import { CryptoData } from '../types/crypto';
import { formatPrice, formatPercentage, formatMarketCap } from '../utils/formatters';

interface MarketScannerProps {
  cryptoData: CryptoData[];
  onSelectCoin: (coinId: string) => void;
}

const MarketScanner: React.FC<MarketScannerProps> = ({ cryptoData, onSelectCoin }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'market_cap' | 'price' | 'change'>('market_cap');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [watchlist, setWatchlist] = useState<Set<string>>(new Set());

  const filteredData = cryptoData
    .filter(coin => 
      coin.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      coin.symbol.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      let aVal: number, bVal: number;
      
      switch (sortBy) {
        case 'market_cap':
          aVal = a.market_cap;
          bVal = b.market_cap;
          break;
        case 'price':
          aVal = a.current_price;
          bVal = b.current_price;
          break;
        case 'change':
          aVal = a.price_change_percentage_24h;
          bVal = b.price_change_percentage_24h;
          break;
        default:
          return 0;
      }

      return sortOrder === 'desc' ? bVal - aVal : aVal - bVal;
    });

  const toggleWatchlist = (coinId: string) => {
    const newWatchlist = new Set(watchlist);
    if (newWatchlist.has(coinId)) {
      newWatchlist.delete(coinId);
    } else {
      newWatchlist.add(coinId);
    }
    setWatchlist(newWatchlist);
  };

  const handleSort = (column: typeof sortBy) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc');
    } else {
      setSortBy(column);
      setSortOrder('desc');
    }
  };

  return (
    <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold">Market Scanner</h3>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search coins..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-gray-700 border border-gray-600 rounded-lg pl-10 pr-4 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-electric-blue focus:border-transparent"
            />
          </div>
          <button className="flex items-center space-x-2 bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded-lg transition-colors duration-200">
            <Filter className="w-4 h-4" />
            <span className="text-sm">Filter</span>
          </button>
        </div>
      </div>

      {/* Table Header */}
      <div className="grid grid-cols-12 gap-4 text-gray-400 text-sm font-medium mb-4 px-4">
        <div className="col-span-1"></div>
        <div className="col-span-3">Coin</div>
        <div 
          className="col-span-2 cursor-pointer hover:text-white transition-colors duration-200 flex items-center space-x-1"
          onClick={() => handleSort('price')}
        >
          <span>Price</span>
          {sortBy === 'price' && (
            sortOrder === 'desc' ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />
          )}
        </div>
        <div 
          className="col-span-2 cursor-pointer hover:text-white transition-colors duration-200 flex items-center space-x-1"
          onClick={() => handleSort('change')}
        >
          <span>24h Change</span>
          {sortBy === 'change' && (
            sortOrder === 'desc' ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />
          )}
        </div>
        <div 
          className="col-span-3 cursor-pointer hover:text-white transition-colors duration-200 flex items-center space-x-1"
          onClick={() => handleSort('market_cap')}
        >
          <span>Market Cap</span>
          {sortBy === 'market_cap' && (
            sortOrder === 'desc' ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />
          )}
        </div>
        <div className="col-span-1">Action</div>
      </div>

      {/* Table Data */}
      <div className="space-y-2 max-h-96 overflow-y-auto">
        {filteredData.map((coin, index) => (
          <div 
            key={coin.id} 
            className="grid grid-cols-12 gap-4 items-center p-4 bg-gray-750 hover:bg-gray-700 rounded-lg transition-colors duration-200 cursor-pointer"
            onClick={() => onSelectCoin(coin.id)}
          >
            <div className="col-span-1">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleWatchlist(coin.id);
                }}
                className={`p-1 rounded transition-colors duration-200 ${
                  watchlist.has(coin.id) ? 'text-warning-amber' : 'text-gray-500 hover:text-warning-amber'
                }`}
              >
                <Star className={`w-4 h-4 ${watchlist.has(coin.id) ? 'fill-current' : ''}`} />
              </button>
            </div>
            
            <div className="col-span-3 flex items-center space-x-3">
              <span className="text-gray-500 text-sm w-6">{coin.market_cap_rank}</span>
              <img src={coin.image} alt={coin.name} className="w-8 h-8 rounded-full" />
              <div>
                <p className="font-medium text-white">{coin.name}</p>
                <p className="text-gray-400 text-sm uppercase">{coin.symbol}</p>
              </div>
            </div>
            
            <div className="col-span-2">
              <p className="font-medium text-white">{formatPrice(coin.current_price)}</p>
            </div>
            
            <div className="col-span-2">
              <div className={`flex items-center space-x-1 ${
                coin.price_change_percentage_24h >= 0 ? 'text-neon-green' : 'text-danger-red'
              }`}>
                {coin.price_change_percentage_24h >= 0 ? (
                  <TrendingUp className="w-4 h-4" />
                ) : (
                  <TrendingDown className="w-4 h-4" />
                )}
                <span className="font-medium">
                  {formatPercentage(coin.price_change_percentage_24h)}
                </span>
              </div>
            </div>
            
            <div className="col-span-3">
              <p className="text-white">{formatMarketCap(coin.market_cap)}</p>
            </div>
            
            <div className="col-span-1">
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectCoin(coin.id);
                }}
                className="bg-electric-blue hover:bg-blue-500 text-white px-3 py-1 rounded text-sm transition-colors duration-200"
              >
                Trade
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MarketScanner;