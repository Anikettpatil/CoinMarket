import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, TrendingDown } from 'lucide-react';

interface TradingChartProps {
  selectedCoin: string;
}

const TradingChart: React.FC<TradingChartProps> = ({ selectedCoin }) => {
  const [timeframe, setTimeframe] = useState('24h');
  const [chartData, setChartData] = useState<number[]>([]);

  useEffect(() => {
    // Generate mock chart data
    const generateMockData = () => {
      const basePrice = Math.random() * 50000 + 20000;
      const data = [];
      for (let i = 0; i < 100; i++) {
        const volatility = (Math.random() - 0.5) * 0.02;
        const price = basePrice * (1 + volatility * i);
        data.push(price);
      }
      return data;
    };

    setChartData(generateMockData());
  }, [selectedCoin, timeframe]);

  const timeframes = ['1h', '4h', '24h', '7d', '30d'];

  const currentPrice = chartData[chartData.length - 1] || 0;
  const previousPrice = chartData[chartData.length - 2] || 0;
  const priceChange = currentPrice - previousPrice;
  const priceChangePercentage = (priceChange / previousPrice) * 100;

  return (
    <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <BarChart3 className="w-6 h-6 text-electric-blue" />
          <h3 className="text-xl font-bold capitalize">{selectedCoin} Trading Chart</h3>
        </div>
        <div className="flex space-x-2">
          {timeframes.map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-3 py-1 rounded-lg text-sm transition-colors duration-200 ${
                timeframe === tf
                  ? 'bg-electric-blue text-white'
                  : 'bg-gray-700 text-gray-400 hover:bg-gray-600'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* Price Display */}
      <div className="mb-6">
        <div className="flex items-center space-x-4">
          <span className="text-3xl font-bold">${currentPrice.toFixed(2)}</span>
          <div className={`flex items-center space-x-1 ${priceChange >= 0 ? 'text-neon-green' : 'text-danger-red'}`}>
            {priceChange >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            <span className="font-medium">
              ${Math.abs(priceChange).toFixed(2)} ({Math.abs(priceChangePercentage).toFixed(2)}%)
            </span>
          </div>
        </div>
      </div>

      {/* Chart Area */}
      <div className="relative h-80 bg-gray-750 rounded-lg p-4">
        <svg className="w-full h-full" viewBox="0 0 800 300">
          <defs>
            <linearGradient id="chartGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#00d4ff" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#00d4ff" stopOpacity="0" />
            </linearGradient>
          </defs>
          
          {/* Chart Line */}
          <polyline
            fill="none"
            stroke="#00d4ff"
            strokeWidth="2"
            points={chartData.map((price, index) => {
              const x = (index / (chartData.length - 1)) * 800;
              const minPrice = Math.min(...chartData);
              const maxPrice = Math.max(...chartData);
              const y = 300 - ((price - minPrice) / (maxPrice - minPrice)) * 280;
              return `${x},${y}`;
            }).join(' ')}
          />
          
          {/* Chart Fill */}
          <polygon
            fill="url(#chartGradient)"
            points={chartData.map((price, index) => {
              const x = (index / (chartData.length - 1)) * 800;
              const minPrice = Math.min(...chartData);
              const maxPrice = Math.max(...chartData);
              const y = 300 - ((price - minPrice) / (maxPrice - minPrice)) * 280;
              return `${x},${y}`;
            }).join(' ') + ' 800,300 0,300'}
          />
        </svg>
      </div>

      {/* Trading Controls */}
      <div className="grid grid-cols-2 gap-4 mt-6">
        <button className="bg-neon-green hover:bg-green-500 text-black font-bold py-3 px-6 rounded-lg transition-colors duration-200">
          Buy {selectedCoin.toUpperCase()}
        </button>
        <button className="bg-danger-red hover:bg-red-600 text-white font-bold py-3 px-6 rounded-lg transition-colors duration-200">
          Sell {selectedCoin.toUpperCase()}
        </button>
      </div>
    </div>
  );
};

export default TradingChart;