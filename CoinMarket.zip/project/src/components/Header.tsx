import React from 'react';
import { Activity, Search, Bell, Settings, User, Menu } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-dark-secondary border-b border-border-primary h-14 flex items-center px-4">
      <div className="flex items-center justify-between w-full">
        {/* Logo */}
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-r from-accent-blue to-accent-green rounded-lg flex items-center justify-center">
            <Activity className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-xl font-bold text-white">ScanX</h1>
          <span className="text-xs text-text-secondary bg-dark-tertiary px-2 py-1 rounded">PRO</span>
        </div>

        {/* Search */}
        <div className="flex-1 max-w-md mx-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-text-secondary" />
            <input
              type="text"
              placeholder="Search markets..."
              className="w-full bg-dark-tertiary border border-border-primary rounded-lg pl-10 pr-4 py-2 text-white placeholder-text-secondary focus:outline-none focus:ring-1 focus:ring-accent-blue focus:border-accent-blue transition-all duration-200"
            />
          </div>
        </div>

        {/* Right Section */}
        <div className="flex items-center space-x-2">
          <button className="relative p-2 text-text-secondary hover:text-white hover:bg-dark-tertiary rounded-lg transition-all duration-200">
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-accent-blue rounded-full"></span>
          </button>
          <button className="p-2 text-text-secondary hover:text-white hover:bg-dark-tertiary rounded-lg transition-all duration-200">
            <Settings className="w-5 h-5" />
          </button>
          <button className="flex items-center space-x-2 bg-dark-tertiary hover:bg-border-primary px-3 py-2 rounded-lg transition-all duration-200">
            <User className="w-4 h-4" />
            <span className="text-sm">Account</span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;