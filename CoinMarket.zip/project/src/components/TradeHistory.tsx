import React, { useState, useEffect } from 'react';
import { Clock, TrendingUp, TrendingDown } from 'lucide-react';

interface Trade {
  id: string;
  pair: string;
  type: 'buy' | 'sell';
  price: number;
  amount: number;
  time: Date;
}

const TradeHistory: React.FC = () => {
  const [trades, setTrades] = useState<Trade[]>([]);

  useEffect(() => {
    const generateMockTrades = () => {
      const pairs = ['BTC/USDT', 'ETH/USDT', 'BNB/USDT', 'ADA/USDT'];
      const newTrades: Trade[] = [];

      for (let i = 0; i < 20; i++) {
        newTrades.push({
          id: `trade-${i}`,
          pair: pairs[Math.floor(Math.random() * pairs.length)],
          type: Math.random() > 0.5 ? 'buy' : 'sell',
          price: Math.random() * 50000 + 1000,
          amount: Math.random() * 10 + 0.1,
          time: new Date(Date.now() - Math.random() * 3600000),
        });
      }

      setTrades(newTrades.sort((a, b) => b.time.getTime() - a.time.getTime()));
    };

    generateMockTrades();
    const interval = setInterval(generateMockTrades, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-border-primary">
        <div className="flex items-center space-x-2">
          <Clock className="w-4 h-4 text-accent-blue" />
          <h3 className="text-sm font-semibold text-white">Recent Trades</h3>
        </div>
      </div>

      {/* Column Headers */}
      <div className="grid grid-cols-4 gap-2 p-3 text-xs text-text-secondary font-medium border-b border-border-primary">
        <div>Price</div>
        <div className="text-right">Amount</div>
        <div className="text-right">Time</div>
        <div className="text-center">Type</div>
      </div>

      {/* Trade List */}
      <div className="flex-1 overflow-y-auto">
        <div className="space-y-0">
          {trades.map((trade) => (
            <div key={trade.id} className="grid grid-cols-4 gap-2 p-2 text-xs hover:bg-dark-tertiary transition-colors duration-200">
              <div className={`font-medium ${trade.type === 'buy' ? 'text-accent-green' : 'text-accent-red'}`}>
                {trade.price.toFixed(2)}
              </div>
              <div className="text-text-secondary text-right">{trade.amount.toFixed(4)}</div>
              <div className="text-text-secondary text-right">
                {trade.time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
              <div className="text-center">
                {trade.type === 'buy' ? (
                  <TrendingUp className="w-3 h-3 text-accent-green mx-auto" />
                ) : (
                  <TrendingDown className="w-3 h-3 text-accent-red mx-auto" />
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TradeHistory;