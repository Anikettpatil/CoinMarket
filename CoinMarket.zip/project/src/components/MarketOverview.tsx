import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, Activity } from 'lucide-react';
import { MarketData, CryptoData } from '../types/crypto';
import { formatPrice, formatPercentage, formatMarketCap } from '../utils/formatters';

interface MarketOverviewProps {
  marketData: MarketData | null;
  cryptoData: CryptoData[];
}

const MarketOverview: React.FC<MarketOverviewProps> = ({ marketData, cryptoData }) => {
  const topGainers = cryptoData
    .filter(coin => coin.price_change_percentage_24h > 0)
    .sort((a, b) => b.price_change_percentage_24h - a.price_change_percentage_24h)
    .slice(0, 5);

  const topLosers = cryptoData
    .filter(coin => coin.price_change_percentage_24h < 0)
    .sort((a, b) => a.price_change_percentage_24h - b.price_change_percentage_24h)
    .slice(0, 5);

  return (
    <div className="space-y-8">
      {/* Market Stats */}
      {marketData && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-gray-800 border border-gray-700 rounded-xl p-6 hover:bg-gray-750 transition-colors duration-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Market Cap</p>
                <p className="text-2xl font-bold text-white">{formatMarketCap(marketData.total_market_cap.usd)}</p>
                <p className={`text-sm ${marketData.market_cap_change_percentage_24h_usd >= 0 ? 'text-neon-green' : 'text-danger-red'}`}>
                  {formatPercentage(marketData.market_cap_change_percentage_24h_usd)}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-electric-blue" />
            </div>
          </div>

          <div className="bg-gray-800 border border-gray-700 rounded-xl p-6 hover:bg-gray-750 transition-colors duration-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">24h Volume</p>
                <p className="text-2xl font-bold text-white">{formatMarketCap(marketData.total_volume.usd)}</p>
              </div>
              <Activity className="w-8 h-8 text-neon-green" />
            </div>
          </div>

          <div className="bg-gray-800 border border-gray-700 rounded-xl p-6 hover:bg-gray-750 transition-colors duration-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Active Cryptocurrencies</p>
                <p className="text-2xl font-bold text-white">{marketData.active_cryptocurrencies.toLocaleString()}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-warning-amber" />
            </div>
          </div>

          <div className="bg-gray-800 border border-gray-700 rounded-xl p-6 hover:bg-gray-750 transition-colors duration-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">BTC Dominance</p>
                <p className="text-2xl font-bold text-white">{marketData.market_cap_percentage.btc.toFixed(1)}%</p>
              </div>
              <div className="w-8 h-8 bg-warning-amber rounded-full flex items-center justify-center text-black font-bold text-sm">
                ₿
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Top Gainers and Losers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
          <h3 className="text-xl font-bold mb-6 flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-neon-green" />
            <span>Top Gainers</span>
          </h3>
          <div className="space-y-4">
            {topGainers.map((coin, index) => (
              <div key={coin.id} className="flex items-center justify-between p-3 bg-gray-750 rounded-lg hover:bg-gray-700 transition-colors duration-200">
                <div className="flex items-center space-x-3">
                  <span className="text-gray-400 text-sm w-4">{index + 1}</span>
                  <img src={coin.image} alt={coin.name} className="w-8 h-8 rounded-full" />
                  <div>
                    <p className="font-medium">{coin.name}</p>
                    <p className="text-gray-400 text-sm uppercase">{coin.symbol}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium">{formatPrice(coin.current_price)}</p>
                  <p className="text-neon-green text-sm">+{formatPercentage(coin.price_change_percentage_24h)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
          <h3 className="text-xl font-bold mb-6 flex items-center space-x-2">
            <TrendingDown className="w-5 h-5 text-danger-red" />
            <span>Top Losers</span>
          </h3>
          <div className="space-y-4">
            {topLosers.map((coin, index) => (
              <div key={coin.id} className="flex items-center justify-between p-3 bg-gray-750 rounded-lg hover:bg-gray-700 transition-colors duration-200">
                <div className="flex items-center space-x-3">
                  <span className="text-gray-400 text-sm w-4">{index + 1}</span>
                  <img src={coin.image} alt={coin.name} className="w-8 h-8 rounded-full" />
                  <div>
                    <p className="font-medium">{coin.name}</p>
                    <p className="text-gray-400 text-sm uppercase">{coin.symbol}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium">{formatPrice(coin.current_price)}</p>
                  <p className="text-danger-red text-sm">{formatPercentage(coin.price_change_percentage_24h)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

    </div>
  );
};

export default MarketOverview;