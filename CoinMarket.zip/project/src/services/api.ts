import { CryptoData, MarketData } from '../types/crypto';

const COINGECKO_API_BASE = 'https://api.coingecko.com/api/v3';

export const fetchCryptoData = async (): Promise<CryptoData[]> => {
  try {
    const response = await fetch(
      `${COINGECKO_API_BASE}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&price_change_percentage=24h`
    );
    
    if (!response.ok) {
      throw new Error('Failed to fetch crypto data');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error fetching crypto data:', error);
    return [];
  }
};

export const fetchMarketData = async (): Promise<MarketData> => {
  try {
    const response = await fetch(`${COINGECKO_API_BASE}/global`);
    
    if (!response.ok) {
      throw new Error('Failed to fetch market data');
    }
    
    const data = await response.json();
    return data.data;
  } catch (error) {
    console.error('Error fetching market data:', error);
    // Return mock data as fallback
    return {
      active_cryptocurrencies: 10000,
      upcoming_icos: 0,
      ongoing_icos: 0,
      ended_icos: 0,
      markets: 500,
      total_market_cap: { usd: 2500000000000 },
      total_volume: { usd: 100000000000 },
      market_cap_percentage: { btc: 45.2, eth: 18.8 },
      market_cap_change_percentage_24h_usd: 2.5,
      updated_at: Date.now() / 1000,
    };
  }
};

export const fetchCoinPrice = async (coinId: string): Promise<number> => {
  try {
    const response = await fetch(
      `${COINGECKO_API_BASE}/simple/price?ids=${coinId}&vs_currencies=usd`
    );
    
    if (!response.ok) {
      throw new Error('Failed to fetch coin price');
    }
    
    const data = await response.json();
    return data[coinId]?.usd || 0;
  } catch (error) {
    console.error('Error fetching coin price:', error);
    return 0;
  }
};